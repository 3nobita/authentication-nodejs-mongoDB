const { default: mongoose } = require('mongoose');
const Mongoose = require('mongoose');
const connect = Mongoose.connect('mongodb://localhost:27017/newBase')

connect.then(()=>{
    console.log('mongodb connected')
})
.catch((error)=>{
    console.error(error)
})  

// create Mongoose.Schema

const LoginSchema = new mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    password:{
        type:String,
        required:true
    }

})

const collection = new mongoose.model('allData',LoginSchema);
module.exports = collection